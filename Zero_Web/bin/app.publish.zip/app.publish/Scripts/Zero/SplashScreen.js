﻿function splash() {
    var time = 3000;
    setTimeout(function () {
        $('#splashscreen').hide();
    }, time);
}
splash();